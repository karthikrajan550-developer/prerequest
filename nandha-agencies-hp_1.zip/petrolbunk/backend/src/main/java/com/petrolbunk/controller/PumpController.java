package com.petrolbunk.controller;

import com.petrolbunk.dto.CreatePumpRequest;
import com.petrolbunk.dto.PumpDto;
import com.petrolbunk.entity.DailyReading;
import com.petrolbunk.entity.Pump;
import com.petrolbunk.repository.DailyReadingRepository;
import com.petrolbunk.repository.PumpRepository;
import com.petrolbunk.service.BusinessValidationException;
import jakarta.validation.Valid;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/pumps")
public class PumpController {

    private final PumpRepository pumpRepository;
    private final DailyReadingRepository readingRepository;

    public PumpController(PumpRepository pumpRepository,
                          DailyReadingRepository readingRepository) {
        this.pumpRepository = pumpRepository;
        this.readingRepository = readingRepository;
    }

    @GetMapping
    public List<PumpDto> getPumps() {
        return pumpRepository.findAllByOrderByDisplayOrderAsc().stream()
                .map(p -> new PumpDto(p.getId(), p.getName(), p.getFuelType(), p.getDisplayOrder()))
                .collect(Collectors.toList());
    }

    /** Add a new pump. It appears at the end of the list. */
    @PostMapping
    @Transactional
    public PumpDto addPump(@Valid @RequestBody CreatePumpRequest req) {
        String name = req.name.trim();
        boolean exists = pumpRepository.findAll().stream()
                .anyMatch(p -> p.getName().equalsIgnoreCase(name));
        if (exists) {
            throw new BusinessValidationException("A pump named '" + name + "' already exists.");
        }
        int nextOrder = pumpRepository.findAll().stream()
                .mapToInt(Pump::getDisplayOrder).max().orElse(0) + 1;
        Pump saved = pumpRepository.save(new Pump(name, req.fuelType, nextOrder));
        return new PumpDto(saved.getId(), saved.getName(), saved.getFuelType(), saved.getDisplayOrder());
    }

    /** Rename a pump or change its fuel type. */
    @PutMapping("/{id}")
    @Transactional
    public PumpDto updatePump(@PathVariable Long id, @Valid @RequestBody CreatePumpRequest req) {
        Pump pump = pumpRepository.findById(id)
                .orElseThrow(() -> new BusinessValidationException("Pump not found."));
        pump.setName(req.name.trim());
        pump.setFuelType(req.fuelType);
        Pump saved = pumpRepository.save(pump);
        return new PumpDto(saved.getId(), saved.getName(), saved.getFuelType(), saved.getDisplayOrder());
    }

    /** Delete a pump and all of its daily readings. */
    @DeleteMapping("/{id}")
    @Transactional
    public void deletePump(@PathVariable Long id) {
        Pump pump = pumpRepository.findById(id)
                .orElseThrow(() -> new BusinessValidationException("Pump not found."));
        // Remove all readings for this pump, then the pump itself.
        List<DailyReading> all = readingRepository.findAll();
        for (DailyReading dr : all) {
            if (dr.getPump() != null && dr.getPump().getId().equals(id)) {
                readingRepository.delete(dr);
            }
        }
        pumpRepository.delete(pump);
    }
}
