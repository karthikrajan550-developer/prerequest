package com.petrolbunk.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Serves the bundled Angular app. Any non-API, non-file route (e.g. /customers,
 * /reports) is forwarded to index.html so Angular's client-side routing works
 * even on a page refresh or direct link.
 */
@Controller
public class SpaController {

    @RequestMapping(value = {
            "/",
            "/{path:[^\\.]*}",
            "/{path:^(?!api).*}/**/{sub:[^\\.]*}"
    })
    public String forward() {
        return "forward:/index.html";
    }
}
