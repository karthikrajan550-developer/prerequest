# Deploying Nandha Agencies - HP on Render (all-in-one, free)

The whole app — frontend, backend, and database — runs as ONE service on Render.
No Vercel, no split. Set aside about 45–60 minutes the first time.

---

## Before you start

Put the project on GitHub (Render deploys from GitHub):

1. Create a free GitHub account if you don't have one.
2. Create a new repository, e.g. `nandha-agencies-hp`.
3. Upload the entire `petrolbunk` folder to it (use GitHub's "Add file -> Upload
   files", or GitHub Desktop).

---

## STEP 1 - Create a free database (Render PostgreSQL)

1. Sign up at https://render.com (free).
2. Click New + -> PostgreSQL.
3. Name it `nandha-db`, choose the Free plan, click Create Database.
4. Wait ~1 minute. On the database page, note these (Connections section):
   - Hostname, Port (5432), Database, Username, Password
5. Build your JDBC URL from those:
   jdbc:postgresql://HOSTNAME:5432/DATABASE

---

## STEP 2 - Deploy the app (Render Web Service)

1. Click New + -> Web Service.
2. Connect GitHub and select your repository.
3. Configure:
   - Root Directory: petrolbunk/backend
   - Build Command: mvn clean package -DskipTests
   - Start Command: java -jar target/nandha-agencies-hp.jar
   - Plan: Free
4. Add these Environment Variables:
   - SPRING_PROFILES_ACTIVE = prod
   - DB_URL = jdbc:postgresql://HOSTNAME:5432/DATABASE  (your values)
   - DB_USER = your database username
   - DB_PASSWORD = your database password
5. Click Create Web Service.

The build takes several minutes the first time (it installs Node, builds the
Angular app, then packages everything into one jar). When it finishes, Render
gives you a URL like https://nandha-agencies-hp.onrender.com

---

## STEP 3 - Open your app

Visit your Render URL:
   https://nandha-agencies-hp.onrender.com

The full app loads - Daily Entry, Customers, Reports, everything - served from
that one address. Because frontend and backend share the same server, there is
no CORS setup and no second URL to manage.

---

## Notes about free hosting

- First load after idle is slow: Render's free service sleeps after ~15 min of
  no use; the next visit takes 30-60 seconds to wake it, then it is fast.
- Data persists in the cloud PostgreSQL database across restarts.
- The free database size limit is far more than a fuel station needs.

---

## Troubleshooting

- Build fails: open the Render build log. Most common cause is the Root
  Directory not being petrolbunk/backend.
- App loads but no data / errors saving: the database env vars are wrong.
  Re-check DB_URL, DB_USER, DB_PASSWORD against the Render database page.
- "Application failed to start" with a database error: confirm
  SPRING_PROFILES_ACTIVE = prod is set exactly.
- Blank page: wait for the first-load wake-up (up to a minute), then refresh.
