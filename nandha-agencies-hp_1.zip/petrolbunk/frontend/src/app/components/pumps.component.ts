import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../services/api.service';
import { FuelType } from '../models/models';

@Component({
  selector: 'app-pumps',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="card">
      <h2>⚙️ Pump Management</h2>
      <p class="muted">Add, rename, or remove pumps. Changes apply to Daily Entry
        and all calculations. Removing a pump also deletes its reading history.</p>

      <div *ngIf="error" class="error">{{ error }}</div>
      <div *ngIf="message" class="success">{{ message }}</div>

      <div class="toolbar">
        <div style="flex:1;min-width:160px;">
          <label>New pump name</label>
          <input type="text" [(ngModel)]="newName" placeholder="e.g. Power-4" />
        </div>
        <div>
          <label>Fuel type</label>
          <select [(ngModel)]="newFuel">
            <option value="POWER_PETROL">Power Petrol</option>
            <option value="PETROL">Petrol</option>
            <option value="DIESEL">Diesel</option>
          </select>
        </div>
        <button (click)="addPump()">Add Pump</button>
      </div>

      <table *ngIf="pumps.length">
        <thead>
          <tr><th>Pump Name</th><th>Fuel Type</th><th></th></tr>
        </thead>
        <tbody>
          <tr *ngFor="let p of pumps">
            <ng-container *ngIf="editId !== p.id">
              <td>{{ p.name }}</td>
              <td><span class="fuel-tag" [ngClass]="'tag-' + p.fuelType">{{ label(p.fuelType) }}</span></td>
              <td style="text-align:center;white-space:nowrap;">
                <button class="expand-btn" (click)="startEdit(p)">Edit</button>
                <button class="expand-btn" (click)="deletePump(p)">Delete</button>
              </td>
            </ng-container>
            <ng-container *ngIf="editId === p.id">
              <td><input type="text" [(ngModel)]="editName" style="width:140px;" /></td>
              <td>
                <select [(ngModel)]="editFuel">
                  <option value="POWER_PETROL">Power Petrol</option>
                  <option value="PETROL">Petrol</option>
                  <option value="DIESEL">Diesel</option>
                </select>
              </td>
              <td style="text-align:center;white-space:nowrap;">
                <button class="expand-btn" (click)="saveEdit(p)">Save</button>
                <button class="expand-btn" (click)="cancelEdit()">Cancel</button>
              </td>
            </ng-container>
          </tr>
        </tbody>
      </table>
      <p *ngIf="!pumps.length" class="muted">No pumps yet. Add one above.</p>
    </div>
  `
})
export class PumpsComponent implements OnInit {
  pumps: any[] = [];
  error = '';
  message = '';

  newName = '';
  newFuel: FuelType = 'POWER_PETROL';

  editId: number | null = null;
  editName = '';
  editFuel: FuelType = 'POWER_PETROL';

  constructor(private api: ApiService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.api.getPumps().subscribe({
      next: p => this.pumps = p,
      error: e => this.error = this.msg(e)
    });
  }

  addPump(): void {
    if (!this.newName.trim()) { this.error = 'Enter a pump name.'; return; }
    this.error = ''; this.message = '';
    this.api.addPump({ name: this.newName, fuelType: this.newFuel }).subscribe({
      next: () => { this.newName = ''; this.message = 'Pump added.'; this.load(); },
      error: e => this.error = this.msg(e)
    });
  }

  startEdit(p: any): void {
    this.editId = p.id;
    this.editName = p.name;
    this.editFuel = p.fuelType;
  }

  cancelEdit(): void { this.editId = null; }

  saveEdit(p: any): void {
    if (!this.editName.trim()) { this.error = 'Pump name cannot be empty.'; return; }
    this.error = ''; this.message = '';
    this.api.updatePump(p.id, { name: this.editName, fuelType: this.editFuel }).subscribe({
      next: () => { this.editId = null; this.message = 'Pump updated.'; this.load(); },
      error: e => this.error = this.msg(e)
    });
  }

  deletePump(p: any): void {
    if (!confirm(`Delete pump "${p.name}" and all its reading history? This cannot be undone.`)) return;
    this.error = ''; this.message = '';
    this.api.deletePump(p.id).subscribe({
      next: () => { this.message = 'Pump removed.'; this.load(); },
      error: e => this.error = this.msg(e)
    });
  }

  label(t: FuelType): string {
    return t === 'POWER_PETROL' ? 'Power Petrol' : t.charAt(0) + t.slice(1).toLowerCase();
  }

  private msg(e: any): string {
    return e?.error?.message || 'Something went wrong. Is the backend running?';
  }
}
