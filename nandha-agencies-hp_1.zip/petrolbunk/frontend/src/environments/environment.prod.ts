// Production: frontend and backend are served from the SAME server (bundled),
// so the API is reached with a relative path — no domain needed.
export const environment = {
  production: true,
  apiBase: '/api'
};
